import java.io.*;
public class TestParser 
{
	public static void main(String[] args)
	{
		try 
		{
			String fileName = "src/infix.txt";
			String line = null;
			FileReader fileReader = new FileReader(fileName);
			BufferedReader buff = new BufferedReader(fileReader);
			
			while((line = buff.readLine()) != null)
			{
				boolean success = Parser1.expression(line);
				if(success)
					System.out.println(line + ": Is Valid");
				else
				{
					System.out.println(line + ": Is NOT Valid");
				}
			}	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
