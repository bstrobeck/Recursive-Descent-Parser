
public class Parser1 
{
	static int cur;
	static String input;
	
	public static boolean expression(String infix)
	{
		if(infix == null || infix.length() == 0)
		{
			return false;
		}
		input = infix;
		cur = 0;
		boolean success;
		success = isExpression(infix);
		if(success)
		{
			cur++;
			if(cur >= infix.length())
			{
				return true;
			}
		}
		return success;
	}

	private static boolean isExpression(String infix) 
	{
		boolean success;
		success = isTerm(infix);
		if(success)
		{
			if(cur >= infix.length())
			{
				return true;
			}
			
			else if(input.charAt(cur) == '+' || input.charAt(cur) == '-')
			{
				cur++;
				if(cur >= infix.length())
				{
					return false;//might throw problems later, but if the logic is right, then if we get to this point the infix would look something like .... A+ 
				}
				else
				{
					success = isTerm(infix.substring(cur));
					return success;
				}
			}
		}
		return success;
	}

	private static boolean isTerm(String infix) 
	{
		boolean success;
		success = isFactor(infix);
		if(success)
		{
			//to get this far, first letter has to come back valid from isFactor
			cur++;
			if(cur >= input.length())
			{
				return true;//to get here means that there is only one, valid letter, so return true all they way back to the top
			}
			else if(input.charAt(cur) == '*' || input.charAt(cur) == '/')
			{
				cur++;//increment again, since we've already proven the point we are at now is a * or /
				if(cur >= infix.length())
				{
					return false;//might throw problems later, but if the logic is right, then if we get to this point the infix would look something like .... A+ 
				}
				return isFactor(infix.substring(cur));
			}
			return success;
		}
		return success;
	}

	private static boolean isFactor(String infix) 
	{
		boolean success;
		if(		infix.charAt(0) == 'A'||infix.charAt(0) == 'B'||infix.charAt(0) == 'C'||infix.charAt(0) == 'D'||//checking we're only using upper case letters
				infix.charAt(0) == 'E'||infix.charAt(0) == 'F'||infix.charAt(0) == 'G'||infix.charAt(0) == 'H'||
				infix.charAt(0) == 'I'||infix.charAt(0) == 'J'||infix.charAt(0) == 'K'||infix.charAt(0) == 'L'||
				infix.charAt(0) == 'M'||infix.charAt(0) == 'N'||infix.charAt(0) == 'O'||infix.charAt(0) == 'P'||
				infix.charAt(0) == 'Q'||infix.charAt(0) == 'R'||infix.charAt(0) == 'S'||infix.charAt(0) == 'T'||
				infix.charAt(0) == 'U'||infix.charAt(0) == 'V'||infix.charAt(0) == 'W'||infix.charAt(0) == 'X'||
				infix.charAt(0) == 'Y'||infix.charAt(0) == 'Z')
				{
					return true;
				}
		else if(infix.charAt(0) == '(')
		{
			cur++;
			success = isExpression(infix.substring(1));
			if(success)
			{
				return isExpression(infix.substring(1));
			}
			else
			{
				return isExpression(infix.substring(1));
			}
		}
		else if(infix.charAt(0) == ')')
		{
			return true;
		}
		return false;
	}
}
