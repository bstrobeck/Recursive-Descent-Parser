//Brandtly Strobeck Data Structures Fall 2017
//This program will take input from a file, and attempt to validate each expression on whether it is grammatically correct, based on the grammar given to us by Tom
public class Parser 
{
	static String INPUT;
	static int CUR;
	
	public static boolean expression(String infix)//will more than likely be the method to call from Tester to start this party off
	{
		if(infix == null || infix.length() == 0)//check for null or empty string
			return false;
		
		INPUT = infix;//assign infix to global INPUT for better visibility 
		CUR = 0;
		if(isExpression(infix))
		{
			return CUR == INPUT.length()-1;//checks to make sure it walked all the way through input
		}
		return false;
	}
	
	private static boolean isExpression(String infix)
	{
		boolean success;
		success = isTerm(infix);
		if(success)//this if will only step inside if there is only one letter passed in, and its valid...
		{
			//CUR++;
			if(CUR >= INPUT.length())
			{
				return true;
			}
			else if(infix.charAt(CUR+1) == '+' || infix.charAt(CUR+1) == '-')
			{
				CUR++;//to have gotten this far, we have validated at least one term, and we have validated the next char is a + or -
				System.out.println(CUR);
				success = isTerm(infix.substring(CUR, infix.length()));//now we need to check if the char after + or - is a valid term
				
					return true;
			}
		}
		return false;
	}

	private static boolean isTerm(String infix) 
	{
		boolean success;
		success = isFactor(infix);
		if(success)
		{
			//later add code to check for * or /
//			char toCheck = infix.charAt(+1);
//			return isFactor(toCheck); 
			return true;
		}
		return false;
	}

	private static boolean isFactor(String infix) 
	{

		if(		infix.charAt(CUR) == 'A'||infix.charAt(CUR) == 'B'||infix.charAt(CUR) == 'C'||infix.charAt(CUR) == 'D'||//checking we're only using upper case letters
				infix.charAt(CUR) == 'E'||infix.charAt(CUR) == 'F'||infix.charAt(CUR) == 'G'||infix.charAt(CUR) == 'H'||
				infix.charAt(CUR) == 'I'||infix.charAt(CUR) == 'J'||infix.charAt(CUR) == 'K'||infix.charAt(CUR) == 'L'||
				infix.charAt(CUR) == 'M'||infix.charAt(CUR) == 'N'||infix.charAt(CUR) == 'O'||infix.charAt(CUR) == 'P'||
				infix.charAt(CUR) == 'Q'||infix.charAt(CUR) == 'R'||infix.charAt(CUR) == 'S'||infix.charAt(CUR) == 'T'||
				infix.charAt(CUR) == 'U'||infix.charAt(CUR) == 'V'||infix.charAt(CUR) == 'W'||infix.charAt(CUR) == 'X'||
				infix.charAt(CUR) == 'Y'||infix.charAt(CUR) == 'Z')
		{
			return true;
		}
//		else if(INPUT.charAt(CUR) == '(') //have to come back and work with the code for where an expression is wrapped in parens.
//		{
//			isFactor(INPUT,CUR++);
//		
//		|| INPUT.charAt(CUR) == ')'
//		}
		return false;
	}

	
	
	
	
}//end class
